package DataBaseWork;

import java.sql.*;

public class MySqlConnection {
    public static Connection getCon(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/SSMSystem?characterEncoding=latin1&useConfigs=maxPerformance";
            Connection con = DriverManager.getConnection(url, "root", "1234.Siddahsan");
            return con;
        }catch(Exception e){
            return null;
        }
    }
}
